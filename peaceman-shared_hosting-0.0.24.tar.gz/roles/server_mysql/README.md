Ansible Role: server_mysql
=========

Install mysql via geerlingguy.mysql and sets up automysqlbackup

Role Variables
--------------

Uses

```
mysql_port:
mysql_firewall_exceptions: []
```

Defines
```
mysql_version: 8.0
```
