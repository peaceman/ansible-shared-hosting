Ansible Role: server_redis
=========

Install a system wide redis-server

Role Variables
--------------

```
redis_enable_system_service: false
redis_service: redis-server
```
