Ansible Role: server_mysql
=========

Install mysql via geerlingguy.mysql and sets up automysqlbackup
