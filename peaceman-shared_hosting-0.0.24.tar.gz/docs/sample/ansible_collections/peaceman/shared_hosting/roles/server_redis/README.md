Ansible Role: server_redis
=========

Install a system wide redis-server

Requirements
------------

Any pre-requisites that may not be covered by Ansible itself or the role should be mentioned here. For instance, if the role uses the EC2 module, it may be a good idea to mention in this section that the boto package is required.

Role Variables
--------------

```
redis_enable_system_service: false
redis_service: redis-server
```
