Ansible Role: app_mysql
=========

Creates mysql user and databases

Requirements
------------

Requires mysql root access through a configured .my.cnf in the
ansible users home folder.

Role Variables
--------------

```
username:
password:
databases:
  -
hosts:
  -
```
